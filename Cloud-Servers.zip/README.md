# basic-api-server


## UML
<img src="./src/UML.png" />


Heroku Link: https://alaa-basic-api-server.herokuapp.com/

Github Actions: https://github.com/Alaa-AbuIssa/basic-api-server/actions

Pull Request: https://github.com/Alaa-AbuIssa/basic-api-server/pull/2